workspace : catkin_ws_v2x/src/HMCL_V2X



catkin_ws_v2x/src/HMCL_V2X/include : 

- V2X/20220406_v2x_lecture_1/j2735/ * (Zoom.o, YawRateConfidence.o ... )



catkin_ws_v2x/src/HMCL_V2X/src : 

- V2X/20220406_v2x_lecture_1/j2735
- V2X/20220406_v2x_lecture_1/asn

- V2X/20220406_v2x_lecture_1/sample/ * (=bsm.c , j2735.c , j2735.h ... )
- .c file -> .cpp file (bsm.c -> bsm.cpp , pvd.c -> pvd.cpp ... )
- make pub.cpp
- V2X/20220406_v2x_lecture_1/j2735/converter-example.c : 
  - delete #error (42, 43)
  - delete int main


catkin_ws_v2x/src/HMCL_V2X/CMakeLists.txt 

catkin_ws_v2x/src/HMCL_V2X/package.xml





